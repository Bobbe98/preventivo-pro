# PreventivoPro

App Flutter per artigiani (fabbri, carpentieri, installatori): preventivi con materiali e manodopera, calcolo di ricarico, sconto e IVA, PDF professionale da mandare su WhatsApp o per email.

## Cosa fa

- **Preventivi**: dati del cliente, oggetto del lavoro, voci di materiale, manodopera e altre spese, stato (bozza, inviato, accettato o rifiutato).
- **Ricarico automatico**: per i materiali inserisci il prezzo di acquisto e l'app applica il ricarico. Nel PDF il cliente vede solo il prezzo di vendita.
- **"Il tuo guadagno"**: vedi quanto ti resta davvero. Questo dato non finisce nel PDF.
- **Listino**: salvi materiali e tariffe orarie e li aggiungi con un tocco. Parte con alcuni articoli di esempio.
- **PDF**: intestazione con i dati della tua azienda, tabella delle voci, totali, condizioni, IBAN e spazio per le firme. Si condivide o si stampa direttamente.
- **Home**: importi "in attesa" e "accettati", ricerca e filtri per stato, duplicazione di un preventivo.
- **Gratis e Pro**: la versione gratuita salva 5 preventivi e aggiunge la scritta "Creato con PreventivoPro". La Pro (4,99 € una tantum) toglie il limite e la scritta e aggiunge il logo.

## Avvio (sul PC con Flutter installato)

```bash
cd preventivo_pro
flutter create . --org it.bobbe98 --platforms android,web
flutter pub get
flutter test          # verifica i calcoli
flutter run           # sul telefono collegato via USB
```

`flutter create .` genera solo le cartelle `android/` e `web/` e non tocca i file che esistono già.

## PRIMA di pubblicare

1. Cambia `segretoCodici` in `lib/pro.dart` con una frase inventata da te e non condividerla.
2. Metti in `linkAcquisto` il link della pagina di vendita (Payhip, Gumroad o il tuo Shopify).
3. Genera i codici da vendere:
   ```bash
   dart run tool/genera_codici.dart 20
   ```
   Consegna un codice per ogni acquisto. All'inizio puoi mandarlo via email a mano; Payhip permette anche di allegare un messaggio o un file al prodotto.

## Pubblicare senza spendere

**Web app gratuita (GitHub Pages):**
```bash
flutter build web --release --base-href /preventivo_pro/
```
Carica il contenuto di `build/web` in un repository GitHub e attiva Pages. Dal telefono si apre il link e si aggiunge alla schermata Home.

**APK da vendere o regalare:**
```bash
flutter build apk --release
```
Il file si trova in `build/app/outputs/flutter-apk/app-release.apk`.

**Play Store** (più avanti): account da 25 $ e 12 tester per 14 giorni. Per gli acquisti dentro l'app Google richiede il suo sistema di pagamento, quindi lì il codice Pro va sostituito con `in_app_purchase`.

## Struttura

```
lib/
  main.dart            tema e lingua italiana
  models.dart          Azienda, Cliente, Voce, Preventivo, listino di partenza
  storage.dart         salvataggio sul telefono (shared_preferences)
  pdf_service.dart     generazione del PDF
  pro.dart             controllo dei codici Pro
  format.dart          formati € e date italiane
  screens/             home, editor, voce, listino, azienda, pdf, pro
tool/genera_codici.dart
test/widget_test.dart  test dei calcoli e dei codici
assets/fonts/          DejaVu Sans (necessario per il simbolo € nel PDF)
```

## Idee per le prossime versioni

- Esportare e importare un backup (JSON su Drive)
- Trasformare un preventivo accettato in "ordine" o in fattura proforma
- Rubrica clienti
- Calcolo del peso di profili e lamiere per ricavare il costo al kg
- Modelli di preventivo (ringhiera, cancello, scala)
