// Genera codici Pro da consegnare a chi compra.
// Uso:  dart run tool/genera_codici.dart 20

import 'dart:math';

import 'package:preventivo_pro/pro.dart';

void main(List<String> args) {
  final quanti = args.isEmpty ? 10 : (int.tryParse(args.first) ?? 10);
  final r = Random.secure();
  const caratteri = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (var i = 0; i < quanti; i++) {
    final corpo =
        List.generate(6, (_) => caratteri[r.nextInt(caratteri.length)]).join();
    print(generaCodice(corpo));
  }
}
