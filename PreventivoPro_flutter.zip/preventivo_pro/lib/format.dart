import 'package:intl/intl.dart';

final _euro = NumberFormat.currency(locale: 'it', symbol: '€', decimalDigits: 2);
final _data = DateFormat('dd/MM/yyyy');

String euro(double v) => _euro.format(v);

String dataIt(DateTime d) => _data.format(d);

/// 2 -> "2", 2.5 -> "2,5", 2.125 -> "2,13"
String numIt(double v) {
  if (v == v.roundToDouble()) return v.toInt().toString();
  var s = v.toStringAsFixed(2);
  if (s.endsWith('0')) s = s.substring(0, s.length - 1);
  return s.replaceAll('.', ',');
}

/// Accetta sia "2,5" che "2.5".
double leggiNum(String s) =>
    double.tryParse(s.trim().replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
