import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'pro.dart';

/// Preventivi salvabili nella versione gratuita.
const limiteGratis = 5;

/// Archivio unico dell'app (salvato sul telefono).
final store = AppStore();

class AppStore extends ChangeNotifier {
  late SharedPreferences _prefs;

  Azienda azienda = Azienda();
  List<Preventivo> preventivi = [];
  List<ArticoloListino> listino = [];
  bool pro = false;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final a = _prefs.getString('azienda');
    if (a != null) {
      try {
        azienda = Azienda.fromJson(Map<String, dynamic>.from(jsonDecode(a) as Map));
      } catch (_) {}
    }
    preventivi = _leggiLista('preventivi', Preventivo.fromJson);
    listino = _prefs.getString('listino') == null
        ? listinoIniziale()
        : _leggiLista('listino', ArticoloListino.fromJson);
    pro = codiceValido(_prefs.getString('codicePro') ?? '');
  }

  List<T> _leggiLista<T>(String chiave, T Function(Map<String, dynamic>) da) {
    final raw = _prefs.getString(chiave);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => da(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  // ---------- Preventivi ----------

  List<Preventivo> get ordinati =>
      [...preventivi]..sort((a, b) => b.data.compareTo(a.data));

  bool get puoCreare => pro || preventivi.length < limiteGratis;

  bool esiste(String id) => preventivi.any((p) => p.id == id);

  String _nuovoId() => DateTime.now().microsecondsSinceEpoch.toString();

  String prossimoNumero() {
    final anno = DateTime.now().year;
    var max = 0;
    for (final p in preventivi) {
      if (p.numero.startsWith('$anno-')) {
        final n = int.tryParse(p.numero.substring(5)) ?? 0;
        if (n > max) max = n;
      }
    }
    return '$anno-${(max + 1).toString().padLeft(3, '0')}';
  }

  Preventivo nuovo() => Preventivo(
        id: _nuovoId(),
        numero: prossimoNumero(),
        data: DateTime.now(),
        validitaGiorni: azienda.validitaGiorni,
        ricarico: azienda.ricaricoDefault,
        iva: azienda.ivaDefault,
      );

  Future<void> salvaPreventivo(Preventivo p) async {
    final i = preventivi.indexWhere((x) => x.id == p.id);
    if (i >= 0) {
      preventivi[i] = p;
    } else {
      preventivi.add(p);
    }
    await _salva('preventivi', preventivi.map((e) => e.toJson()).toList());
  }

  Future<void> eliminaPreventivo(String id) async {
    preventivi.removeWhere((p) => p.id == id);
    await _salva('preventivi', preventivi.map((e) => e.toJson()).toList());
  }

  Future<Preventivo> duplica(Preventivo originale) async {
    final c = originale.copia()
      ..id = _nuovoId()
      ..numero = prossimoNumero()
      ..data = DateTime.now()
      ..stato = StatoPreventivo.bozza;
    await salvaPreventivo(c);
    return c;
  }

  Future<void> cambiaStato(Preventivo p, StatoPreventivo s) async {
    p.stato = s;
    await salvaPreventivo(p);
  }

  // ---------- Azienda ----------

  Future<void> salvaAzienda(Azienda a) async {
    azienda = a;
    await _prefs.setString('azienda', jsonEncode(a.toJson()));
    notifyListeners();
  }

  // ---------- Listino ----------

  Future<void> salvaArticolo(ArticoloListino a, {int? indice}) async {
    if (indice != null && indice >= 0 && indice < listino.length) {
      listino[indice] = a;
    } else {
      listino.add(a);
    }
    listino.sort((x, y) =>
        x.descrizione.toLowerCase().compareTo(y.descrizione.toLowerCase()));
    await _salva('listino', listino.map((e) => e.toJson()).toList());
  }

  Future<void> eliminaArticolo(int indice) async {
    listino.removeAt(indice);
    await _salva('listino', listino.map((e) => e.toJson()).toList());
  }

  // ---------- Pro ----------

  Future<bool> attivaPro(String codice) async {
    if (!codiceValido(codice)) return false;
    await _prefs.setString('codicePro', codice.trim().toUpperCase());
    pro = true;
    notifyListeners();
    return true;
  }

  // ---------- Statistiche ----------

  double totalePer(StatoPreventivo s) => preventivi
      .where((p) => p.stato == s)
      .fold<double>(0, (t, p) => t + p.totale);

  Future<void> _salva(String chiave, List<Map<String, dynamic>> dati) async {
    await _prefs.setString(chiave, jsonEncode(dati));
    notifyListeners();
  }
}
