import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../storage.dart';
import 'widgets.dart';

/// Listino articoli. Con [selezione] = true un tocco restituisce l'articolo.
class ListinoScreen extends StatefulWidget {
  const ListinoScreen({super.key, this.selezione = false});
  final bool selezione;

  @override
  State<ListinoScreen> createState() => _ListinoScreenState();
}

class _ListinoScreenState extends State<ListinoScreen> {
  String _cerca = '';

  Future<void> _modifica([int? indice]) async {
    final orig = indice == null ? null : store.listino[indice];
    final a = await showDialog<ArticoloListino>(
      context: context,
      builder: (_) => _ArticoloDialog(articolo: orig),
    );
    if (a != null) await store.salvaArticolo(a, indice: indice);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final q = _cerca.toLowerCase();
        final indici = [
          for (var i = 0; i < store.listino.length; i++)
            if (store.listino[i].descrizione.toLowerCase().contains(q)) i
        ];
        return Scaffold(
          appBar: AppBar(
              title: Text(widget.selezione ? 'Scegli dal listino' : 'Listino')),
          floatingActionButton: FloatingActionButton(
            tooltip: 'Nuovo articolo',
            onPressed: () => _modifica(),
            child: const Icon(Icons.add),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              TextField(
                onChanged: (s) => setState(() => _cerca = s),
                decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search), hintText: 'Cerca articolo'),
              ),
              const SizedBox(height: 8),
              if (!widget.selezione)
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text(
                      'Materiali a prezzo di acquisto: il ricarico si applica nel preventivo.'),
                ),
              if (indici.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: Text('Nessun articolo')),
                ),
              for (final i in indici)
                Card(
                  margin: const EdgeInsets.only(bottom: 6),
                  child: ListTile(
                    leading: Icon(iconaTipo(store.listino[i].tipo)),
                    title: Text(store.listino[i].descrizione),
                    subtitle: Text(
                        '${store.listino[i].tipo.etichetta} · ${euro(store.listino[i].prezzo)} / ${store.listino[i].unita}'),
                    onTap: widget.selezione
                        ? () => Navigator.pop(context, store.listino[i])
                        : () => _modifica(i),
                    trailing: widget.selezione
                        ? const Icon(Icons.add_circle_outline)
                        : IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => store.eliminaArticolo(i),
                          ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ArticoloDialog extends StatefulWidget {
  const _ArticoloDialog({this.articolo});
  final ArticoloListino? articolo;

  @override
  State<_ArticoloDialog> createState() => _ArticoloDialogState();
}

class _ArticoloDialogState extends State<_ArticoloDialog> {
  late final _desc =
      TextEditingController(text: widget.articolo?.descrizione ?? '');
  late final _unita = TextEditingController(text: widget.articolo?.unita ?? 'pz');
  late final _prezzo = TextEditingController(
      text: widget.articolo == null ? '' : numIt(widget.articolo!.prezzo));
  late TipoVoce _tipo = widget.articolo?.tipo ?? TipoVoce.materiale;

  @override
  void dispose() {
    _desc.dispose();
    _unita.dispose();
    _prezzo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.articolo == null ? 'Nuovo articolo' : 'Modifica articolo'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<TipoVoce>(
            value: _tipo,
            decoration: const InputDecoration(labelText: 'Tipo'),
            items: [
              for (final t in TipoVoce.values)
                DropdownMenuItem(value: t, child: Text(t.etichetta)),
            ],
            onChanged: (t) => setState(() => _tipo = t ?? _tipo),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _desc,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Descrizione'),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _prezzo,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText:
                      _tipo == TipoVoce.materiale ? 'Prezzo acquisto' : 'Prezzo',
                  suffixText: '€',
                ),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 90,
              child: TextField(
                controller: _unita,
                decoration: const InputDecoration(labelText: 'Unità'),
              ),
            ),
          ]),
        ]),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annulla')),
        FilledButton(
          onPressed: () {
            if (_desc.text.trim().isEmpty) return;
            Navigator.pop(
              context,
              ArticoloListino(
                descrizione: _desc.text.trim(),
                tipo: _tipo,
                unita: _unita.text.trim(),
                prezzo: leggiNum(_prezzo.text),
              ),
            );
          },
          child: const Text('Salva'),
        ),
      ],
    );
  }
}
