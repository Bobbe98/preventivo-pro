import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models.dart';
import '../storage.dart';
import 'pro_screen.dart';
import 'widgets.dart';

class AziendaScreen extends StatefulWidget {
  const AziendaScreen({super.key});

  @override
  State<AziendaScreen> createState() => _AziendaScreenState();
}

class _AziendaScreenState extends State<AziendaScreen> {
  late final Azienda a = Azienda.fromJson(store.azienda.toJson());

  Future<void> _scegliLogo() async {
    if (!store.pro) {
      await apriPro(context, motivo: 'Il logo sui preventivi è una funzione Pro.');
      if (!store.pro) return;
    }
    final foto = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 500,
      maxHeight: 500,
      imageQuality: 85,
    );
    if (foto == null) return;
    final bytes = await foto.readAsBytes();
    setState(() => a.logoBase64 = base64Encode(bytes));
  }

  Future<void> _salva() async {
    await store.salvaAzienda(a);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Dati azienda salvati')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('La mia azienda'),
        actions: [
          TextButton(onPressed: _salva, child: const Text('Salva')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
        children: [
          const Sezione('Logo'),
          Row(children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                border: Border.all(color: tema.colorScheme.outlineVariant),
                borderRadius: BorderRadius.circular(8),
              ),
              clipBehavior: Clip.antiAlias,
              child: a.logoBase64 == null
                  ? const Icon(Icons.image_outlined, size: 32)
                  : Image.memory(base64Decode(a.logoBase64!), fit: BoxFit.contain),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  OutlinedButton.icon(
                    onPressed: _scegliLogo,
                    icon: Icon(store.pro ? Icons.upload : Icons.lock_outline),
                    label: Text(store.pro ? 'Scegli logo' : 'Logo (Pro)'),
                  ),
                  if (a.logoBase64 != null)
                    TextButton(
                      onPressed: () => setState(() => a.logoBase64 = null),
                      child: const Text('Rimuovi'),
                    ),
                ],
              ),
            ),
          ]),
          const Sezione('Dati in testa al preventivo'),
          Campo(
              etichetta: 'Nome azienda *',
              valore: a.nome,
              icona: Icons.business,
              onChanged: (s) => a.nome = s),
          Campo(
              etichetta: 'Indirizzo',
              valore: a.indirizzo,
              icona: Icons.place_outlined,
              onChanged: (s) => a.indirizzo = s),
          Campo(
              etichetta: 'Partita IVA',
              valore: a.piva,
              tastiera: TextInputType.text,
              onChanged: (s) => a.piva = s),
          Campo(
              etichetta: 'Telefono',
              valore: a.telefono,
              tastiera: TextInputType.phone,
              onChanged: (s) => a.telefono = s),
          Campo(
              etichetta: 'Email',
              valore: a.email,
              tastiera: TextInputType.emailAddress,
              onChanged: (s) => a.email = s),
          Campo(
              etichetta: 'IBAN (facoltativo)',
              valore: a.iban,
              tastiera: TextInputType.text,
              onChanged: (s) => a.iban = s),
          const Sezione('Valori predefiniti'),
          Row(children: [
            Expanded(
              child: CampoNumero(
                  etichetta: 'IVA',
                  valore: a.ivaDefault,
                  suffisso: '%',
                  onChanged: (v) => a.ivaDefault = v),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: CampoNumero(
                  etichetta: 'Ricarico mat.',
                  valore: a.ricaricoDefault,
                  suffisso: '%',
                  onChanged: (v) => a.ricaricoDefault = v),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: CampoNumero(
                  etichetta: 'Validità',
                  valore: a.validitaGiorni.toDouble(),
                  suffisso: 'gg',
                  onChanged: (v) => a.validitaGiorni = v.round()),
            ),
          ]),
          const Sezione('Condizioni (in fondo al PDF)'),
          Campo(
              etichetta: 'Pagamento, garanzia, esclusioni…',
              valore: a.condizioni,
              righe: 4,
              onChanged: (s) => a.condizioni = s),
          const SizedBox(height: 8),
          FilledButton(onPressed: _salva, child: const Text('Salva')),
        ],
      ),
    );
  }
}
