import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';

Color coloreStato(StatoPreventivo s) => switch (s) {
      StatoPreventivo.bozza => Colors.blueGrey,
      StatoPreventivo.inviato => Colors.orange.shade700,
      StatoPreventivo.accettato => Colors.green.shade700,
      StatoPreventivo.rifiutato => Colors.red.shade700,
    };

IconData iconaTipo(TipoVoce t) => switch (t) {
      TipoVoce.materiale => Icons.inventory_2_outlined,
      TipoVoce.manodopera => Icons.engineering_outlined,
      TipoVoce.altro => Icons.local_shipping_outlined,
    };

class ChipStato extends StatelessWidget {
  const ChipStato(this.stato, {super.key});
  final StatoPreventivo stato;

  @override
  Widget build(BuildContext context) {
    final c = coloreStato(stato);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(stato.etichetta,
          style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

class Sezione extends StatelessWidget {
  const Sezione(this.titolo, {super.key, this.azione});
  final String titolo;
  final Widget? azione;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Row(
          children: [
            Expanded(
              child: Text(titolo.toUpperCase(),
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      letterSpacing: 0.8)),
            ),
            if (azione != null) azione!,
          ],
        ),
      );
}

/// Campo di testo che aggiorna il modello a ogni modifica.
class Campo extends StatelessWidget {
  const Campo({
    super.key,
    required this.etichetta,
    required this.valore,
    required this.onChanged,
    this.tastiera,
    this.righe = 1,
    this.suffisso,
    this.icona,
  });

  final String etichetta;
  final String valore;
  final ValueChanged<String> onChanged;
  final TextInputType? tastiera;
  final int righe;
  final String? suffisso;
  final IconData? icona;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextFormField(
          initialValue: valore,
          onChanged: onChanged,
          keyboardType: righe > 1 ? TextInputType.multiline : tastiera,
          minLines: righe,
          maxLines: righe > 1 ? righe + 3 : 1,
          textCapitalization: tastiera == null && righe == 1
              ? TextCapitalization.sentences
              : TextCapitalization.none,
          decoration: InputDecoration(
            labelText: etichetta,
            suffixText: suffisso,
            prefixIcon: icona == null ? null : Icon(icona, size: 20),
          ),
        ),
      );
}

/// Campo numerico (accetta la virgola).
class CampoNumero extends StatelessWidget {
  const CampoNumero({
    super.key,
    required this.etichetta,
    required this.valore,
    required this.onChanged,
    this.suffisso,
  });

  final String etichetta;
  final double valore;
  final ValueChanged<double> onChanged;
  final String? suffisso;

  @override
  Widget build(BuildContext context) => TextFormField(
        initialValue: valore == 0 ? '' : numIt(valore),
        onChanged: (s) => onChanged(leggiNum(s)),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: etichetta,
          suffixText: suffisso,
          hintText: '0',
        ),
      );
}

class RigaImporto extends StatelessWidget {
  const RigaImporto(this.etichetta, this.valore,
      {super.key, this.forte = false, this.colore});
  final String etichetta;
  final String valore;
  final bool forte;
  final Color? colore;

  @override
  Widget build(BuildContext context) {
    final stile = forte
        ? Theme.of(context)
            .textTheme
            .titleLarge
            ?.copyWith(fontWeight: FontWeight.bold, color: colore)
        : Theme.of(context).textTheme.bodyLarge?.copyWith(color: colore);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(child: Text(etichetta, style: stile)),
          Text(valore, style: stile),
        ],
      ),
    );
  }
}
