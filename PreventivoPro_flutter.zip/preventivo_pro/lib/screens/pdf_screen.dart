import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../models.dart';
import '../pdf_service.dart';
import '../storage.dart';
import 'pro_screen.dart';

/// Anteprima del PDF con i pulsanti Condividi (WhatsApp, email…) e Stampa.
class PdfScreen extends StatelessWidget {
  const PdfScreen({super.key, required this.preventivo});
  final Preventivo preventivo;

  String get _nomeFile {
    final cliente = preventivo.cliente.nome
        .trim()
        .replaceAll(RegExp(r'[^A-Za-z0-9]+'), '_');
    return 'Preventivo_${preventivo.numero}${cliente.isEmpty ? '' : '_$cliente'}.pdf';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PDF ${preventivo.numero}'),
        actions: [
          IconButton(
            tooltip: 'Condividi',
            icon: const Icon(Icons.share),
            onPressed: () async {
              final bytes = await PdfService.genera(
                  preventivo, store.azienda,
                  pro: store.pro);
              await Printing.sharePdf(bytes: bytes, filename: _nomeFile);
              if (preventivo.stato == StatoPreventivo.bozza) {
                await store.cambiaStato(preventivo, StatoPreventivo.inviato);
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          if (!store.pro)
            Material(
              color: Colors.amber.shade100,
              child: ListTile(
                dense: true,
                leading: const Icon(Icons.workspace_premium, color: Colors.black87),
                title: const Text(
                  'Con Pro: il tuo logo e niente scritta "Creato con PreventivoPro"',
                  style: TextStyle(color: Colors.black87),
                ),
                onTap: () => apriPro(context),
              ),
            ),
          Expanded(
            child: PdfPreview(
              build: (formato) => PdfService.genera(
                  preventivo, store.azienda,
                  pro: store.pro, formato: formato),
              pdfFileName: _nomeFile,
              canChangePageFormat: false,
              canChangeOrientation: false,
              canDebug: false,
              allowPrinting: true,
              allowSharing: false, // usa il pulsante Condividi in alto
            ),
          ),
        ],
      ),
    );
  }
}
