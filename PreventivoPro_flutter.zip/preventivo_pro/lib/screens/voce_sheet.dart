import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../storage.dart';

/// Apre il pannello per creare/modificare una voce. Ritorna null se annullato.
Future<Voce?> mostraVoceSheet(
  BuildContext context, {
  Voce? voce,
  required double ricarico,
  bool nuova = false,
}) =>
    showModalBottomSheet<Voce>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _VoceSheet(
        voce: voce ?? Voce(),
        ricarico: ricarico,
        nuova: nuova || voce == null,
      ),
    );

class _VoceSheet extends StatefulWidget {
  const _VoceSheet(
      {required this.voce, required this.ricarico, required this.nuova});
  final Voce voce;
  final double ricarico;
  final bool nuova;

  @override
  State<_VoceSheet> createState() => _VoceSheetState();
}

class _VoceSheetState extends State<_VoceSheet> {
  late final Voce v = widget.voce;
  late final _desc = TextEditingController(text: v.descrizione);
  late final _qta = TextEditingController(text: numIt(v.quantita));
  late final _prezzo =
      TextEditingController(text: v.prezzo == 0 ? '' : numIt(v.prezzo));
  late final _unita = TextEditingController(text: v.unita);
  bool _salvaInListino = false;

  @override
  void dispose() {
    _desc.dispose();
    _qta.dispose();
    _prezzo.dispose();
    _unita.dispose();
    super.dispose();
  }

  void _aggiorna() => setState(() {
        v.descrizione = _desc.text.trim();
        v.quantita = leggiNum(_qta.text);
        v.prezzo = leggiNum(_prezzo.text);
        v.unita = _unita.text.trim();
      });

  Future<void> _conferma() async {
    _aggiorna();
    if (v.descrizione.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Scrivi una descrizione')));
      return;
    }
    if (_salvaInListino) {
      await store.salvaArticolo(ArticoloListino(
        descrizione: v.descrizione,
        tipo: v.tipo,
        unita: v.unita,
        prezzo: v.prezzo,
      ));
    }
    if (mounted) Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final materiale = v.tipo == TipoVoce.materiale;

    return Padding(
      padding: EdgeInsets.fromLTRB(
          16, 0, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(widget.nuova ? 'Nuova voce' : 'Modifica voce',
                style: tema.textTheme.titleLarge),
            const SizedBox(height: 12),
            SegmentedButton<TipoVoce>(
              segments: [
                for (final t in TipoVoce.values)
                  ButtonSegment(value: t, label: Text(t.etichetta)),
              ],
              selected: {v.tipo},
              onSelectionChanged: (s) {
                v.tipo = s.first;
                if (v.tipo == TipoVoce.manodopera && _unita.text == 'pz') {
                  _unita.text = 'h';
                }
                _aggiorna();
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _desc,
              autofocus: widget.nuova && v.descrizione.isEmpty,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Descrizione'),
              onChanged: (_) => _aggiorna(),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _qta,
                  autofocus: widget.nuova && v.descrizione.isNotEmpty,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Quantità'),
                  onChanged: (_) => _aggiorna(),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _unita,
                  decoration: const InputDecoration(labelText: 'Unità'),
                  onChanged: (_) => _aggiorna(),
                ),
              ),
            ]),
            const SizedBox(height: 6),
            Wrap(spacing: 6, children: [
              for (final u in unitaComuni)
                ActionChip(
                  label: Text(u),
                  onPressed: () {
                    _unita.text = u;
                    _aggiorna();
                  },
                ),
            ]),
            const SizedBox(height: 10),
            TextField(
              controller: _prezzo,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: materiale
                    ? 'Prezzo di ACQUISTO per unità'
                    : 'Prezzo per unità',
                suffixText: '€',
                helperText: materiale
                    ? 'Al cliente: ${euro(v.prezzoVendita(widget.ricarico))} (ricarico ${numIt(widget.ricarico)}%)'
                    : null,
              ),
              onChanged: (_) => _aggiorna(),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: tema.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Importo voce'),
                  Text(euro(v.totale(widget.ricarico)),
                      style: tema.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: _salvaInListino,
              onChanged: (b) => setState(() => _salvaInListino = b ?? false),
              title: const Text('Salva anche nel listino'),
            ),
            FilledButton(
              onPressed: _conferma,
              child: Text(widget.nuova ? 'Aggiungi' : 'Aggiorna'),
            ),
          ],
        ),
      ),
    );
  }
}
