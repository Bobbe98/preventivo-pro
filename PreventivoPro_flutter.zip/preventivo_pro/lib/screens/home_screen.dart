import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../storage.dart';
import 'azienda_screen.dart';
import 'editor_screen.dart';
import 'listino_screen.dart';
import 'pro_screen.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  StatoPreventivo? _filtro;
  String _cerca = '';

  Future<void> _nuovo() async {
    if (!store.puoCreare) {
      await apriPro(context,
          motivo:
              'Hai raggiunto i $limiteGratis preventivi della versione gratuita.');
      if (!store.puoCreare) return;
    }
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditorScreen(preventivo: store.nuovo())),
    );
  }

  Future<void> _apri(Preventivo p) => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => EditorScreen(preventivo: p.copia())),
      );

  Future<void> _menu(Preventivo p, String azione) async {
    switch (azione) {
      case 'duplica':
        if (!store.puoCreare) {
          await apriPro(context,
              motivo: 'Per duplicare serve spazio per un nuovo preventivo.');
          return;
        }
        final c = await store.duplica(p);
        if (mounted) await _apri(c);
      case 'elimina':
        final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Eliminare il preventivo?'),
            content: Text('${p.numero} · ${p.titolo}'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Annulla')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Elimina')),
            ],
          ),
        );
        if (ok == true) await store.eliminaPreventivo(p.id);
      default:
        final stato =
            StatoPreventivo.values.where((s) => s.name == azione).firstOrNull;
        if (stato != null) await store.cambiaStato(p, stato);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final tema = Theme.of(context);
        final q = _cerca.toLowerCase();
        final lista = store.ordinati.where((p) {
          if (_filtro != null && p.stato != _filtro) return false;
          if (q.isEmpty) return true;
          return p.cliente.nome.toLowerCase().contains(q) ||
              p.oggetto.toLowerCase().contains(q) ||
              p.numero.contains(q);
        }).toList();

        return Scaffold(
          appBar: AppBar(
            title: Row(children: [
              const Text('PreventivoPro'),
              if (store.pro) ...[
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade600,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('PRO',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                ),
              ],
            ]),
            actions: [
              IconButton(
                tooltip: 'Listino',
                icon: const Icon(Icons.list_alt),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ListinoScreen())),
              ),
              IconButton(
                tooltip: 'La mia azienda',
                icon: const Icon(Icons.business),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const AziendaScreen())),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _nuovo,
            icon: const Icon(Icons.add),
            label: const Text('Nuovo preventivo'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            children: [
              if (!store.azienda.configurata)
                Card(
                  color: tema.colorScheme.primaryContainer,
                  child: ListTile(
                    leading: const Icon(Icons.info_outline),
                    title: const Text('Inserisci i dati della tua azienda'),
                    subtitle:
                        const Text('Compariranno in testa a ogni preventivo.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const AziendaScreen())),
                  ),
                ),
              _Riepilogo(),
              const SizedBox(height: 12),
              if (store.preventivi.isNotEmpty) ...[
                TextField(
                  onChanged: (s) => setState(() => _cerca = s),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Cerca cliente, lavoro o numero',
                  ),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(children: [
                    _chip('Tutti', null),
                    for (final s in StatoPreventivo.values) _chip(s.etichetta, s),
                  ]),
                ),
                const SizedBox(height: 4),
              ],
              if (store.preventivi.isEmpty)
                const _Vuoto()
              else if (lista.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: Text('Nessun preventivo trovato')),
                ),
              for (final p in lista)
                Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    contentPadding: const EdgeInsets.fromLTRB(16, 6, 4, 6),
                    onTap: () => _apri(p),
                    title: Text(p.titolo,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          [
                            p.numero,
                            dataIt(p.data),
                            if (p.oggetto.isNotEmpty) p.oggetto
                          ].join(' · '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        ChipStato(p.stato),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(euro(p.totale),
                            style: tema.textTheme.titleMedium
                                ?.copyWith(fontWeight: FontWeight.bold)),
                        PopupMenuButton<String>(
                          onSelected: (a) => _menu(p, a),
                          itemBuilder: (_) => [
                            for (final s in StatoPreventivo.values)
                              if (s != p.stato)
                                PopupMenuItem(
                                    value: s.name,
                                    child: Text('Segna come ${s.etichetta.toLowerCase()}')),
                            const PopupMenuDivider(),
                            const PopupMenuItem(
                                value: 'duplica', child: Text('Duplica')),
                            const PopupMenuItem(
                                value: 'elimina', child: Text('Elimina')),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              if (!store.pro)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: TextButton.icon(
                    onPressed: () => apriPro(context),
                    icon: const Icon(Icons.workspace_premium_outlined),
                    label: Text(
                        'Versione gratuita: ${store.preventivi.length}/$limiteGratis preventivi · Passa a Pro'),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _chip(String testo, StatoPreventivo? s) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: ChoiceChip(
          label: Text(testo),
          selected: _filtro == s,
          onSelected: (_) => setState(() => _filtro = s),
        ),
      );
}

class _Riepilogo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget box(String titolo, String valore, Color colore) => Expanded(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(titolo, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  FittedBox(
                    child: Text(valore,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold, color: colore)),
                  ),
                ],
              ),
            ),
          ),
        );

    return Row(children: [
      box('In attesa', euro(store.totalePer(StatoPreventivo.inviato)),
          coloreStato(StatoPreventivo.inviato)),
      box('Accettati', euro(store.totalePer(StatoPreventivo.accettato)),
          coloreStato(StatoPreventivo.accettato)),
      box('Preventivi', '${store.preventivi.length}',
          Theme.of(context).colorScheme.primary),
    ]);
  }
}

class _Vuoto extends StatelessWidget {
  const _Vuoto();

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 24),
        child: Column(children: [
          Icon(Icons.request_quote_outlined,
              size: 64, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 12),
          Text('Il tuo primo preventivo in 2 minuti',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          const Text(
            'Aggiungi materiali e ore di lavoro: l\'app calcola ricarico, IVA e totale e crea il PDF da mandare al cliente.',
            textAlign: TextAlign.center,
          ),
        ]),
      );
}
