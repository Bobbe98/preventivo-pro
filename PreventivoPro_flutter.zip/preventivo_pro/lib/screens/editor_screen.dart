import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../storage.dart';
import 'listino_screen.dart';
import 'pdf_screen.dart';
import 'voce_sheet.dart';
import 'widgets.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.preventivo});

  /// Copia di lavoro: viene salvata solo con "Salva" o "PDF".
  final Preventivo preventivo;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final Preventivo p = widget.preventivo;
  bool _modificato = false;

  void _cambia(VoidCallback f) => setState(() {
        f();
        _modificato = true;
      });

  Future<void> _salva({bool avviso = true}) async {
    await store.salvaPreventivo(p);
    if (!mounted) return;
    setState(() => _modificato = false);
    if (avviso) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Preventivo salvato')));
    }
  }

  Future<void> _pdf() async {
    if (p.voci.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Aggiungi almeno una voce prima di creare il PDF')));
      return;
    }
    await _salva(avviso: false);
    if (!mounted) return;
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => PdfScreen(preventivo: p)));
  }

  Future<void> _modificaVoce([int? i]) async {
    final v = await mostraVoceSheet(context,
        voce: i == null ? null : p.voci[i].copia(), ricarico: p.ricarico);
    if (v == null) return;
    _cambia(() {
      if (i == null) {
        p.voci.add(v);
      } else {
        p.voci[i] = v;
      }
    });
  }

  Future<void> _dalListino() async {
    final a = await Navigator.push<ArticoloListino>(
      context,
      MaterialPageRoute(builder: (_) => const ListinoScreen(selezione: true)),
    );
    if (a == null || !mounted) return;
    // Chiede subito la quantità partendo dall'articolo scelto.
    final v = await mostraVoceSheet(context,
        voce: a.comeVoce(), ricarico: p.ricarico, nuova: true);
    if (v != null) _cambia(() => p.voci.add(v));
  }

  Future<bool> _confermaUscita() async {
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Modifiche non salvate'),
        content: const Text('Vuoi salvare il preventivo prima di uscire?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, 'esci'),
              child: const Text('Esci senza salvare')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, 'salva'),
              child: const Text('Salva')),
        ],
      ),
    );
    if (r == 'salva') await _salva(avviso: false);
    return r != null;
  }

  Future<void> _scegliData() async {
    final d = await showDatePicker(
      context: context,
      initialDate: p.data,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) _cambia(() => p.data = d);
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final nuovo = !store.esiste(p.id);

    return PopScope(
      canPop: !_modificato,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final esci = await _confermaUscita();
        if (esci && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(nuovo ? 'Nuovo preventivo' : 'Preventivo ${p.numero}'),
          actions: [
            IconButton(
              tooltip: 'Salva',
              icon: const Icon(Icons.save_outlined),
              onPressed: _salva,
            ),
          ],
        ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Row(children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Totale IVA inclusa', style: tema.textTheme.bodySmall),
                    Text(euro(p.totale),
                        style: tema.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              FilledButton.icon(
                onPressed: _pdf,
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('Crea PDF'),
              ),
            ]),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            // ---------------- Cliente ----------------
            const Sezione('Cliente'),
            Campo(
                etichetta: 'Nome o ragione sociale *',
                valore: p.cliente.nome,
                icona: Icons.person_outline,
                onChanged: (s) => _cambia(() => p.cliente.nome = s)),
            Campo(
                etichetta: 'Indirizzo',
                valore: p.cliente.indirizzo,
                icona: Icons.place_outlined,
                onChanged: (s) => _cambia(() => p.cliente.indirizzo = s)),
            Row(children: [
              Expanded(
                child: Campo(
                    etichetta: 'Telefono',
                    valore: p.cliente.telefono,
                    tastiera: TextInputType.phone,
                    onChanged: (s) => _cambia(() => p.cliente.telefono = s)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Campo(
                    etichetta: 'P.IVA / CF',
                    valore: p.cliente.pivaCf,
                    tastiera: TextInputType.text,
                    onChanged: (s) => _cambia(() => p.cliente.pivaCf = s)),
              ),
            ]),
            Campo(
                etichetta: 'Email',
                valore: p.cliente.email,
                tastiera: TextInputType.emailAddress,
                onChanged: (s) => _cambia(() => p.cliente.email = s)),

            // ---------------- Lavoro ----------------
            const Sezione('Lavoro'),
            Campo(
                etichetta: 'Oggetto (es. Fornitura e posa ringhiera)',
                valore: p.oggetto,
                onChanged: (s) => _cambia(() => p.oggetto = s)),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _scegliData,
                  icon: const Icon(Icons.event),
                  label: Text(dataIt(p.data)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<StatoPreventivo>(
                  value: p.stato,
                  decoration: const InputDecoration(labelText: 'Stato'),
                  items: [
                    for (final s in StatoPreventivo.values)
                      DropdownMenuItem(value: s, child: Text(s.etichetta)),
                  ],
                  onChanged: (s) {
                    if (s != null) _cambia(() => p.stato = s);
                  },
                ),
              ),
            ]),
            const SizedBox(height: 10),
            CampoNumero(
                etichetta: 'Validità offerta',
                valore: p.validitaGiorni.toDouble(),
                suffisso: 'giorni',
                onChanged: (v) => _cambia(() => p.validitaGiorni = v.round())),

            // ---------------- Voci ----------------
            Sezione('Voci (${p.voci.length})'),
            if (p.voci.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'Aggiungi materiali, ore di lavoro e altre spese.\nPer i materiali inserisci il prezzo di acquisto: il ricarico lo applica l\'app.',
                  style: tema.textTheme.bodyMedium
                      ?.copyWith(color: tema.colorScheme.onSurfaceVariant),
                ),
              ),
            for (var i = 0; i < p.voci.length; i++)
              Dismissible(
                key: ObjectKey(p.voci[i]),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  color: Colors.red.shade400,
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                onDismissed: (_) => _cambia(() => p.voci.removeAt(i)),
                child: Card(
                  margin: const EdgeInsets.only(bottom: 6),
                  child: ListTile(
                    onTap: () => _modificaVoce(i),
                    leading: Icon(iconaTipo(p.voci[i].tipo)),
                    title: Text(p.voci[i].descrizione.isEmpty
                        ? '(senza descrizione)'
                        : p.voci[i].descrizione),
                    subtitle: Text(
                        '${numIt(p.voci[i].quantita)} ${p.voci[i].unita} × ${euro(p.voci[i].prezzoVendita(p.ricarico))}'),
                    trailing: Text(euro(p.voci[i].totale(p.ricarico)),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            const SizedBox(height: 4),
            Row(children: [
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: () => _modificaVoce(),
                  icon: const Icon(Icons.add),
                  label: const Text('Aggiungi voce'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _dalListino,
                  icon: const Icon(Icons.list_alt),
                  label: const Text('Dal listino'),
                ),
              ),
            ]),

            // ---------------- Calcoli ----------------
            const Sezione('Ricarico, sconto e IVA'),
            Row(key: const ValueKey('calcoli'), children: [
              Expanded(
                child: CampoNumero(
                    etichetta: 'Ricarico mat.',
                    valore: p.ricarico,
                    suffisso: '%',
                    onChanged: (v) => _cambia(() => p.ricarico = v)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: CampoNumero(
                    etichetta: 'Sconto',
                    valore: p.sconto,
                    suffisso: '%',
                    onChanged: (v) => _cambia(() => p.sconto = v)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: CampoNumero(
                    etichetta: 'IVA',
                    valore: p.iva,
                    suffisso: '%',
                    onChanged: (v) => _cambia(() => p.iva = v)),
              ),
            ]),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  RigaImporto('Subtotale', euro(p.subtotale)),
                  if (p.sconto > 0)
                    RigaImporto('Sconto ${numIt(p.sconto)}%',
                        '- ${euro(p.importoSconto)}'),
                  RigaImporto('Imponibile', euro(p.imponibile)),
                  RigaImporto('IVA ${numIt(p.iva)}%', euro(p.importoIva)),
                  const Divider(),
                  RigaImporto('Totale', euro(p.totale), forte: true),
                ]),
              ),
            ),
            Card(
              color: Colors.green.withValues(alpha: 0.08),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(Icons.visibility_off_outlined,
                          size: 16, color: tema.colorScheme.onSurfaceVariant),
                      const SizedBox(width: 6),
                      Text('Solo per te, non va nel PDF',
                          style: tema.textTheme.bodySmall),
                    ]),
                    const SizedBox(height: 8),
                    RigaImporto(
                        'Costo materiali (acquisto)', euro(p.costoMateriali)),
                    RigaImporto('Il tuo guadagno', euro(p.guadagno),
                        forte: true,
                        colore: p.guadagno >= 0
                            ? Colors.green.shade700
                            : Colors.red.shade700),
                  ],
                ),
              ),
            ),

            // ---------------- Note ----------------
            const Sezione('Note per il cliente'),
            Campo(
                key: const ValueKey('note'),
                etichetta: 'Es. tempi di consegna, esclusioni…',
                valore: p.note,
                righe: 3,
                onChanged: (s) => _cambia(() => p.note = s)),
          ],
        ),
      ),
    );
  }
}
