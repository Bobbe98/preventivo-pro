import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../pro.dart';
import '../storage.dart';

Future<void> apriPro(BuildContext context, {String? motivo}) =>
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProScreen(motivo: motivo)),
    );

class ProScreen extends StatefulWidget {
  const ProScreen({super.key, this.motivo});
  final String? motivo;

  @override
  State<ProScreen> createState() => _ProScreenState();
}

class _ProScreenState extends State<ProScreen> {
  final _codice = TextEditingController();
  String? _errore;

  @override
  void dispose() {
    _codice.dispose();
    super.dispose();
  }

  Future<void> _attiva() async {
    final ok = await store.attivaPro(_codice.text);
    if (!mounted) return;
    if (!ok) {
      setState(() => _errore = 'Codice non valido. Controlla di averlo copiato bene.');
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PreventivoPro attivato. Grazie!')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    const vantaggi = [
      (Icons.all_inclusive, 'Preventivi illimitati',
          'La gratuita ne salva $limiteGratis.'),
      (Icons.image_outlined, 'Il tuo logo sul PDF',
          'Preventivi che sembrano di una ditta strutturata.'),
      (Icons.verified_outlined, 'Niente scritta "Creato con PreventivoPro"',
          'Il PDF è tutto tuo.'),
      (Icons.update, 'Tutti gli aggiornamenti futuri', 'Paghi una volta sola.'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('PreventivoPro')),
      body: store.pro
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('Hai già la versione Pro attiva. Buon lavoro!',
                    textAlign: TextAlign.center),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                if (widget.motivo != null)
                  Card(
                    color: tema.colorScheme.errorContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(widget.motivo!),
                    ),
                  ),
                const SizedBox(height: 8),
                Icon(Icons.workspace_premium,
                    size: 56, color: Colors.amber.shade700),
                const SizedBox(height: 8),
                Text('Passa a Pro',
                    textAlign: TextAlign.center,
                    style: tema.textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.bold)),
                Text('$prezzoPro una volta sola',
                    textAlign: TextAlign.center,
                    style: tema.textTheme.titleMedium),
                const SizedBox(height: 16),
                for (final (icona, titolo, testo) in vantaggi)
                  ListTile(
                    leading: Icon(icona, color: tema.colorScheme.primary),
                    title: Text(titolo),
                    subtitle: Text(testo),
                  ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => launchUrl(Uri.parse(linkAcquisto),
                      mode: LaunchMode.externalApplication),
                  icon: const Icon(Icons.shopping_cart_outlined),
                  label: Text('Acquista a $prezzoPro'),
                ),
                const SizedBox(height: 28),
                Text('Hai già un codice?', style: tema.textTheme.titleSmall),
                const SizedBox(height: 8),
                TextField(
                  controller: _codice,
                  textCapitalization: TextCapitalization.characters,
                  decoration: InputDecoration(
                    hintText: 'PP-XXXXXX-XXXXXX',
                    errorText: _errore,
                  ),
                  onChanged: (_) {
                    if (_errore != null) setState(() => _errore = null);
                  },
                ),
                const SizedBox(height: 8),
                OutlinedButton(
                    onPressed: _attiva, child: const Text('Attiva codice')),
              ],
            ),
    );
  }
}
