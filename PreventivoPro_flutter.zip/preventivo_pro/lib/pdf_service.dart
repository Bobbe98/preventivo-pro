import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'format.dart';
import 'models.dart';

/// Crea il PDF del preventivo da consegnare al cliente.
/// Il PDF mostra SOLO i prezzi di vendita: costi di acquisto e guadagno
/// restano nell'app.
class PdfService {
  static pw.Font? _base;
  static pw.Font? _bold;

  static Future<void> _caricaFont() async {
    _base ??= pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
    _bold ??=
        pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));
  }

  static Future<Uint8List> genera(
    Preventivo p,
    Azienda a, {
    required bool pro,
    PdfPageFormat formato = PdfPageFormat.a4,
  }) async {
    await _caricaFont();
    final accento = PdfColor.fromHex('#1F4E79');
    final grigio = PdfColor.fromHex('#6B7280');
    final chiaro = PdfColor.fromHex('#EEF3F8');

    final doc = pw.Document(
      title: 'Preventivo ${p.numero}',
      author: a.nome,
      theme: pw.ThemeData.withFont(base: _base!, bold: _bold!),
    );

    final logo = pro ? _logo(a.logoBase64) : null;

    final piccolo = pw.TextStyle(fontSize: 8.5, color: grigio);
    final normale = const pw.TextStyle(fontSize: 9.5);
    final grassetto = pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold);

    pw.Widget rigaTotale(String etichetta, String valore, {bool forte = false}) =>
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 8),
          color: forte ? accento : null,
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(etichetta,
                  style: forte
                      ? pw.TextStyle(
                          color: PdfColors.white,
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 11)
                      : normale),
              pw.Text(valore,
                  style: forte
                      ? pw.TextStyle(
                          color: PdfColors.white,
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 11)
                      : normale),
            ],
          ),
        );

    final datiAzienda = <String>[
      if (a.indirizzo.isNotEmpty) a.indirizzo,
      if (a.piva.isNotEmpty) 'P.IVA ${a.piva}',
      if (a.telefono.isNotEmpty) 'Tel. ${a.telefono}',
      if (a.email.isNotEmpty) a.email,
    ];

    final datiCliente = <String>[
      if (p.cliente.indirizzo.isNotEmpty) p.cliente.indirizzo,
      if (p.cliente.pivaCf.isNotEmpty) 'P.IVA/CF ${p.cliente.pivaCf}',
      if (p.cliente.telefono.isNotEmpty) 'Tel. ${p.cliente.telefono}',
      if (p.cliente.email.isNotEmpty) p.cliente.email,
    ];

    doc.addPage(
      pw.MultiPage(
        pageFormat: formato,
        margin: const pw.EdgeInsets.fromLTRB(36, 36, 36, 30),
        footer: (ctx) => pw.Container(
          margin: const pw.EdgeInsets.only(top: 12),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(pro ? '' : 'Creato con PreventivoPro', style: piccolo),
              pw.Text('Pagina ${ctx.pageNumber} di ${ctx.pagesCount}',
                  style: piccolo),
            ],
          ),
        ),
        build: (ctx) => [
          // Intestazione
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              if (logo != null)
                pw.Container(
                  width: 70,
                  height: 70,
                  margin: const pw.EdgeInsets.only(right: 12),
                  child: pw.Image(logo, fit: pw.BoxFit.contain),
                ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(a.nome.isEmpty ? 'La tua azienda' : a.nome,
                        style: pw.TextStyle(
                            fontSize: 16,
                            fontWeight: pw.FontWeight.bold,
                            color: accento)),
                    pw.SizedBox(height: 4),
                    for (final r in datiAzienda) pw.Text(r, style: piccolo),
                  ],
                ),
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('PREVENTIVO',
                      style: pw.TextStyle(
                          fontSize: 18,
                          fontWeight: pw.FontWeight.bold,
                          color: accento)),
                  pw.Text('N. ${p.numero}', style: grassetto),
                  pw.Text('Data: ${dataIt(p.data)}', style: normale),
                  pw.Text('Valido fino al: ${dataIt(p.scadenza)}',
                      style: piccolo),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 18),

          // Cliente
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(
              color: chiaro,
              borderRadius: pw.BorderRadius.circular(4),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('SPETT.LE', style: piccolo),
                pw.Text(p.cliente.nome.isEmpty ? '-' : p.cliente.nome,
                    style: pw.TextStyle(
                        fontSize: 11, fontWeight: pw.FontWeight.bold)),
                for (final r in datiCliente) pw.Text(r, style: normale),
              ],
            ),
          ),

          if (p.oggetto.isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.RichText(
              text: pw.TextSpan(children: [
                pw.TextSpan(text: 'Oggetto: ', style: grassetto),
                pw.TextSpan(text: p.oggetto, style: normale),
              ]),
            ),
          ],
          pw.SizedBox(height: 12),

          // Voci
          pw.TableHelper.fromTextArray(
            headers: ['Descrizione', 'Q.tà', 'U.M.', 'Prezzo', 'Importo'],
            data: [
              for (final v in p.voci)
                [
                  v.descrizione,
                  numIt(v.quantita),
                  v.unita,
                  euro(v.prezzoVendita(p.ricarico)),
                  euro(v.totale(p.ricarico)),
                ],
            ],
            headerStyle: pw.TextStyle(
                color: PdfColors.white,
                fontWeight: pw.FontWeight.bold,
                fontSize: 9),
            headerDecoration: pw.BoxDecoration(color: accento),
            cellStyle: normale,
            cellPadding:
                const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
            oddRowDecoration: pw.BoxDecoration(color: chiaro),
            border: null,
            columnWidths: {
              0: const pw.FlexColumnWidth(5),
              1: const pw.FlexColumnWidth(1.1),
              2: const pw.FlexColumnWidth(1.1),
              3: const pw.FlexColumnWidth(1.8),
              4: const pw.FlexColumnWidth(2),
            },
            cellAlignments: {
              0: pw.Alignment.centerLeft,
              1: pw.Alignment.centerRight,
              2: pw.Alignment.center,
              3: pw.Alignment.centerRight,
              4: pw.Alignment.centerRight,
            },
          ),
          pw.SizedBox(height: 12),

          // Totali
          pw.Row(
            children: [
              pw.Spacer(),
              pw.SizedBox(
                width: 230,
                child: pw.Column(children: [
                  rigaTotale('Subtotale', euro(p.subtotale)),
                  if (p.sconto > 0)
                    rigaTotale('Sconto ${numIt(p.sconto)}%',
                        '- ${euro(p.importoSconto)}'),
                  if (p.sconto > 0) rigaTotale('Imponibile', euro(p.imponibile)),
                  rigaTotale('IVA ${numIt(p.iva)}%', euro(p.importoIva)),
                  pw.SizedBox(height: 4),
                  rigaTotale('TOTALE', euro(p.totale), forte: true),
                ]),
              ),
            ],
          ),

          if (p.note.isNotEmpty) ...[
            pw.SizedBox(height: 16),
            pw.Text('Note', style: grassetto),
            pw.Text(p.note, style: normale),
          ],
          if (a.condizioni.isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.Text('Condizioni', style: grassetto),
            pw.Text(a.condizioni, style: normale),
          ],
          if (a.iban.isNotEmpty) ...[
            pw.SizedBox(height: 6),
            pw.Text('IBAN: ${a.iban}', style: normale),
          ],

          // Firma
          pw.SizedBox(height: 36),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              _firma('Il fornitore', piccolo),
              _firma('Per accettazione (il cliente)', piccolo),
            ],
          ),
        ],
      ),
    );

    return doc.save();
  }

  static pw.MemoryImage? _logo(String? base64) {
    if (base64 == null || base64.isEmpty) return null;
    try {
      return pw.MemoryImage(base64Decode(base64));
    } catch (_) {
      return null;
    }
  }

  static pw.Widget _firma(String etichetta, pw.TextStyle stile) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Container(
            width: 180,
            height: 28,
            decoration: const pw.BoxDecoration(
              border: pw.Border(bottom: pw.BorderSide(width: 0.6)),
            ),
          ),
          pw.SizedBox(height: 3),
          pw.Text(etichetta, style: stile),
        ],
      );
}
