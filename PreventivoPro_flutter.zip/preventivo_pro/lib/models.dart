// Modelli dati di PreventivoPro.

enum TipoVoce { materiale, manodopera, altro }

extension TipoVoceX on TipoVoce {
  String get etichetta => switch (this) {
        TipoVoce.materiale => 'Materiale',
        TipoVoce.manodopera => 'Manodopera',
        TipoVoce.altro => 'Altro',
      };
}

enum StatoPreventivo { bozza, inviato, accettato, rifiutato }

extension StatoPreventivoX on StatoPreventivo {
  String get etichetta => switch (this) {
        StatoPreventivo.bozza => 'Bozza',
        StatoPreventivo.inviato => 'Inviato',
        StatoPreventivo.accettato => 'Accettato',
        StatoPreventivo.rifiutato => 'Rifiutato',
      };
}

T _enumDa<T extends Enum>(List<T> valori, Object? nome, T predefinito) {
  for (final v in valori) {
    if (v.name == nome) return v;
  }
  return predefinito;
}

double _d(Object? v, [double predefinito = 0]) =>
    v is num ? v.toDouble() : predefinito;

String _s(Object? v) => v is String ? v : '';

Map<String, dynamic> _mappa(Object? v) =>
    v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};

class Azienda {
  String nome;
  String indirizzo;
  String piva;
  String telefono;
  String email;
  String iban;
  String condizioni;
  String? logoBase64;
  double ivaDefault;
  double ricaricoDefault;
  int validitaGiorni;

  Azienda({
    this.nome = '',
    this.indirizzo = '',
    this.piva = '',
    this.telefono = '',
    this.email = '',
    this.iban = '',
    this.condizioni =
        'Pagamento: 30% all\'ordine, saldo a fine lavori. Prezzi validi salvo variazioni del costo dei materiali.',
    this.logoBase64,
    this.ivaDefault = 22,
    this.ricaricoDefault = 30,
    this.validitaGiorni = 30,
  });

  bool get configurata => nome.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {
        'nome': nome,
        'indirizzo': indirizzo,
        'piva': piva,
        'telefono': telefono,
        'email': email,
        'iban': iban,
        'condizioni': condizioni,
        'logo': logoBase64,
        'iva': ivaDefault,
        'ricarico': ricaricoDefault,
        'validita': validitaGiorni,
      };

  factory Azienda.fromJson(Map<String, dynamic> j) => Azienda(
        nome: _s(j['nome']),
        indirizzo: _s(j['indirizzo']),
        piva: _s(j['piva']),
        telefono: _s(j['telefono']),
        email: _s(j['email']),
        iban: _s(j['iban']),
        condizioni: _s(j['condizioni']),
        logoBase64: j['logo'] is String ? j['logo'] as String : null,
        ivaDefault: _d(j['iva'], 22),
        ricaricoDefault: _d(j['ricarico'], 30),
        validitaGiorni: _d(j['validita'], 30).toInt(),
      );
}

class Cliente {
  String nome;
  String indirizzo;
  String pivaCf;
  String telefono;
  String email;

  Cliente({
    this.nome = '',
    this.indirizzo = '',
    this.pivaCf = '',
    this.telefono = '',
    this.email = '',
  });

  Map<String, dynamic> toJson() => {
        'nome': nome,
        'indirizzo': indirizzo,
        'pivaCf': pivaCf,
        'telefono': telefono,
        'email': email,
      };

  factory Cliente.fromJson(Map<String, dynamic> j) => Cliente(
        nome: _s(j['nome']),
        indirizzo: _s(j['indirizzo']),
        pivaCf: _s(j['pivaCf']),
        telefono: _s(j['telefono']),
        email: _s(j['email']),
      );
}

/// Una riga del preventivo.
/// Per i materiali [prezzo] è il prezzo di ACQUISTO: al cliente
/// viene applicato il ricarico del preventivo.
class Voce {
  String descrizione;
  TipoVoce tipo;
  double quantita;
  String unita;
  double prezzo;

  Voce({
    this.descrizione = '',
    this.tipo = TipoVoce.materiale,
    this.quantita = 1,
    this.unita = 'pz',
    this.prezzo = 0,
  });

  double prezzoVendita(double ricarico) =>
      tipo == TipoVoce.materiale ? prezzo * (1 + ricarico / 100) : prezzo;

  double totale(double ricarico) => quantita * prezzoVendita(ricarico);

  double get costo => tipo == TipoVoce.materiale ? quantita * prezzo : 0;

  Voce copia() => Voce.fromJson(toJson());

  Map<String, dynamic> toJson() => {
        'descrizione': descrizione,
        'tipo': tipo.name,
        'quantita': quantita,
        'unita': unita,
        'prezzo': prezzo,
      };

  factory Voce.fromJson(Map<String, dynamic> j) => Voce(
        descrizione: _s(j['descrizione']),
        tipo: _enumDa(TipoVoce.values, j['tipo'], TipoVoce.materiale),
        quantita: _d(j['quantita'], 1),
        unita: _s(j['unita']),
        prezzo: _d(j['prezzo']),
      );
}

class Preventivo {
  String id;
  String numero;
  DateTime data;
  int validitaGiorni;
  String oggetto;
  Cliente cliente;
  List<Voce> voci;
  double ricarico;
  double sconto;
  double iva;
  String note;
  StatoPreventivo stato;

  Preventivo({
    required this.id,
    required this.numero,
    required this.data,
    this.validitaGiorni = 30,
    this.oggetto = '',
    Cliente? cliente,
    List<Voce>? voci,
    this.ricarico = 30,
    this.sconto = 0,
    this.iva = 22,
    this.note = '',
    this.stato = StatoPreventivo.bozza,
  })  : cliente = cliente ?? Cliente(),
        voci = voci ?? [];

  double get subtotale =>
      voci.fold<double>(0, (s, v) => s + v.totale(ricarico));
  double get importoSconto => subtotale * sconto / 100;
  double get imponibile => subtotale - importoSconto;
  double get importoIva => imponibile * iva / 100;
  double get totale => imponibile + importoIva;

  /// Quanto spendi tu per i materiali (prezzi di acquisto).
  double get costoMateriali => voci.fold<double>(0, (s, v) => s + v.costo);

  /// Quello che ti resta: manodopera + ricarico materiali - sconto.
  double get guadagno => imponibile - costoMateriali;

  DateTime get scadenza => data.add(Duration(days: validitaGiorni));

  String get titolo =>
      cliente.nome.trim().isEmpty ? 'Cliente da inserire' : cliente.nome;

  Preventivo copia() => Preventivo.fromJson(toJson());

  Map<String, dynamic> toJson() => {
        'id': id,
        'numero': numero,
        'data': data.toIso8601String(),
        'validita': validitaGiorni,
        'oggetto': oggetto,
        'cliente': cliente.toJson(),
        'voci': voci.map((v) => v.toJson()).toList(),
        'ricarico': ricarico,
        'sconto': sconto,
        'iva': iva,
        'note': note,
        'stato': stato.name,
      };

  factory Preventivo.fromJson(Map<String, dynamic> j) => Preventivo(
        id: _s(j['id']),
        numero: _s(j['numero']),
        data: DateTime.tryParse(_s(j['data'])) ?? DateTime.now(),
        validitaGiorni: _d(j['validita'], 30).toInt(),
        oggetto: _s(j['oggetto']),
        cliente: Cliente.fromJson(_mappa(j['cliente'])),
        voci: (j['voci'] is List ? j['voci'] as List : const [])
            .map((e) => Voce.fromJson(_mappa(e)))
            .toList(),
        ricarico: _d(j['ricarico'], 30),
        sconto: _d(j['sconto']),
        iva: _d(j['iva'], 22),
        note: _s(j['note']),
        stato: _enumDa(StatoPreventivo.values, j['stato'], StatoPreventivo.bozza),
      );
}

/// Articolo salvato per inserirlo al volo nei preventivi.
class ArticoloListino {
  String descrizione;
  TipoVoce tipo;
  String unita;
  double prezzo;

  ArticoloListino({
    required this.descrizione,
    this.tipo = TipoVoce.materiale,
    this.unita = 'pz',
    this.prezzo = 0,
  });

  Voce comeVoce({double quantita = 1}) => Voce(
        descrizione: descrizione,
        tipo: tipo,
        quantita: quantita,
        unita: unita,
        prezzo: prezzo,
      );

  Map<String, dynamic> toJson() => {
        'descrizione': descrizione,
        'tipo': tipo.name,
        'unita': unita,
        'prezzo': prezzo,
      };

  factory ArticoloListino.fromJson(Map<String, dynamic> j) => ArticoloListino(
        descrizione: _s(j['descrizione']),
        tipo: _enumDa(TipoVoce.values, j['tipo'], TipoVoce.materiale),
        unita: _s(j['unita']),
        prezzo: _d(j['prezzo']),
      );
}

/// Listino di partenza (prezzi indicativi, l'utente li modifica).
List<ArticoloListino> listinoIniziale() => [
      ArticoloListino(descrizione: 'Tubolare ferro 40x40x2', unita: 'm', prezzo: 4.50),
      ArticoloListino(descrizione: 'Piatto ferro 40x5', unita: 'm', prezzo: 2.20),
      ArticoloListino(descrizione: 'Lamiera inox AISI 304 sp. 2 mm', unita: 'm²', prezzo: 45),
      ArticoloListino(descrizione: 'Lamiera alluminio sp. 3 mm', unita: 'm²', prezzo: 38),
      ArticoloListino(descrizione: 'Manodopera officina', tipo: TipoVoce.manodopera, unita: 'h', prezzo: 35),
      ArticoloListino(descrizione: 'Posa in opera', tipo: TipoVoce.manodopera, unita: 'h', prezzo: 40),
      ArticoloListino(descrizione: 'Verniciatura a polvere', tipo: TipoVoce.altro, unita: 'm²', prezzo: 18),
      ArticoloListino(descrizione: 'Trasporto', tipo: TipoVoce.altro, unita: 'forfait', prezzo: 60),
    ];

const unitaComuni = ['pz', 'm', 'm²', 'kg', 'h', 'forfait'];
