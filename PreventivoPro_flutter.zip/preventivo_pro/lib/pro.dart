// Versione Pro sbloccata con un codice (niente Play Store necessario).
//
// Formato codice: PP-XXXXXX-YYYYYY
//   XXXXXX = 6 caratteri casuali, YYYYYY = firma calcolata col segreto.
// I codici si generano con:  dart run tool/genera_codici.dart 20
//
// IMPORTANTE: cambia [segretoCodici] PRIMA di pubblicare l'app e non
// condividerlo. Se lo cambi dopo, i codici già venduti smettono di funzionare.
//
// Questo file non importa Flutter, così lo può usare anche lo script.

import 'dart:convert';

import 'package:crypto/crypto.dart';

const segretoCodici = 'CAMBIA-QUESTA-FRASE-SEGRETA-2026';

const prezzoPro = '4,99 €';

/// Pagina dove si compra la Pro (Payhip, Gumroad, il tuo Shopify...).
const linkAcquisto = 'https://payhip.com/';

String _firma(String corpo) => sha256
    .convert(utf8.encode('$corpo|$segretoCodici'))
    .toString()
    .substring(0, 6)
    .toUpperCase();

String generaCodice(String corpo) => 'PP-$corpo-${_firma(corpo)}';

bool codiceValido(String codice) {
  final m = RegExp(r'^PP-([A-Z0-9]{6})-([A-F0-9]{6})$')
      .firstMatch(codice.trim().toUpperCase());
  if (m == null) return false;
  return _firma(m.group(1)!) == m.group(2);
}
