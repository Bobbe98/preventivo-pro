// Test dei calcoli: esegui con  flutter test
import 'package:flutter_test/flutter_test.dart';
import 'package:preventivo_pro/models.dart';
import 'package:preventivo_pro/pro.dart';

void main() {
  test('ricarico solo sui materiali, sconto e IVA', () {
    final p = Preventivo(id: '1', numero: '2026-001', data: DateTime(2026, 9, 24),
        ricarico: 30, sconto: 10, iva: 22, voci: [
      Voce(descrizione: 'Tubolare', tipo: TipoVoce.materiale, quantita: 10, unita: 'm', prezzo: 5),
      Voce(descrizione: 'Saldatura', tipo: TipoVoce.manodopera, quantita: 4, unita: 'h', prezzo: 35),
    ]);
    // materiale 10 x 5 x 1,30 = 65 ; manodopera 4 x 35 = 140
    expect(p.subtotale, closeTo(205, 0.001));
    expect(p.importoSconto, closeTo(20.5, 0.001));
    expect(p.imponibile, closeTo(184.5, 0.001));
    expect(p.importoIva, closeTo(40.59, 0.001));
    expect(p.totale, closeTo(225.09, 0.001));
    expect(p.costoMateriali, closeTo(50, 0.001));
    expect(p.guadagno, closeTo(134.5, 0.001));
  });

  test('salvataggio e lettura JSON', () {
    final p = Preventivo(id: '1', numero: '2026-001', data: DateTime(2026, 9, 24),
        voci: [Voce(descrizione: 'X', quantita: 2, prezzo: 3)]);
    final c = Preventivo.fromJson(p.toJson());
    expect(c.voci.single.descrizione, 'X');
    expect(c.totale, closeTo(p.totale, 0.001));
  });

  test('codici Pro', () {
    final codice = generaCodice('ABC234');
    expect(codiceValido(codice), isTrue);
    expect(codiceValido(codice.toLowerCase()), isTrue);
    expect(codiceValido('PP-ABC234-000000'), isFalse);
    expect(codiceValido('ciao'), isFalse);
  });
}
